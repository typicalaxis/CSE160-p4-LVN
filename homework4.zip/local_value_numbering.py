import re

#TESTS 4 and 7 infinte loop and I have no idea why, likely my lack of proper patching
#there is no patching, and original variables get overwritten with numbered ones
#   I misread that, and it is too late to change it


# perform the local value numbering optimization
def LVN(program):
    block_tokens = "branch|label|bneq|beq"
    # returns 3 items:
    
    # 1. a new program (list of classier instructions)
    # with the LVN optimization applied

    # 2. a list of new variables required (e.g. numbered virtual
    # registers and program variables)
    new_var = []
    # 3. a number with how many instructions were replaced
    replaced_instr = 0  
    
    block_list = []
    block = []
    #return program,new_var,replaced_instr
    
    #seperates program into blocks
    for instr in program:
        if(re.match(block_tokens,instr)):   #new block
            block.append(instr)
            block_list.append(block)
            block = []
        else:
            block.append(instr)
    block_list.append(block)                #appending the last block to the list

    new_name_counter = 0
    for b in block_list:
        global_counter = 0
        var_dict = {}                   #dict of vars to keep track of what the most recent number is for that var
        beg_var_dict = {}               #defunct patching dicts
        end_var_dict = {}               #anything that uses these two is not working

        for instr in b:
            index = b.index(instr)
            instr = instr.replace(" ","")
            #artifact of how my new_names are added to the 3addrlist
            nnm = re.match("virtual_reg_new_name",instr)
            if(nnm):
                new_name_counter = new_name_counter+1

            two_match = re.match("(\S+)=(\S+)\((\S+),(\S+)\)",instr)        #pattern matchiing for 2 arg functions
            one_match = re.match("(\S+)=(\S+)\((\S+)\)",instr)              #pattern matching for 1 arg functions
            assi = re.match("(\S+)=(\S+)",instr)                            #pattern matching for assignments
            if(two_match):
                dest = two_match[1]
                if(re.match("_new_name|vr",dest) !=None):           #if dest is an applicible var
                    new_dest = dest +"_%s"%global_counter
                    var_dict.update({dest:new_dest})                #adds or updates the new var to the var dict
                    end_var_dict[dest] = new_dest
                    if(beg_var_dict.get(dest) ==None):
                        beg_var_dict[dest] = new_dest
                    dest = new_dest
                    new_var = new_var + [dest]                      #adds to the functions new vars
                    global_counter = global_counter +1
                inst = two_match[2]
                arg1 = two_match[3]

                if(re.match("_new_name|vr",arg1) !=None):          #if arg1 is an applicible var
                    if(var_dict.get(arg1)):                     #if arg1 has already been numbered
                        new_arg1 = var_dict.get(arg1)
                    else:                                       #else make a new numbered var
                        new_arg1 = arg1 +"_%s"%global_counter
                        global_counter = global_counter +1
                        new_var = new_var + [new_arg1]
                    end_var_dict[arg1] = new_arg1
                    if(beg_var_dict.get(arg1) ==None):
                        beg_var_dict[arg1] = new_arg1
                    arg1 = new_arg1
                arg2 = two_match[4]
                if(re.match("_new_name|vr",arg2)!=None):        #if arg2 is an applicible var
                    if(var_dict.get(arg2)):                     #if arg2 has already been numbered
                        new_arg2 = var_dict.get(arg2)
                    else:                                       #else make a new numbered var
                        new_arg2 = arg2 +"_%s"%global_counter
                        global_counter = global_counter +1
                        new_var = new_var + [new_arg2]
                    end_var_dict[arg2] = new_arg2
                    if(beg_var_dict.get(arg2) ==None):
                        beg_var_dict[arg2] = new_arg2
                    arg2 = new_arg2
                #replacing the instruction
                instr = dest + "=" + inst + "(" + arg1 +","+ arg2 + ");"
                b[index] = instr
            
            elif(one_match):
                dest = one_match[1]
                if(re.match("_new_name|vr",dest) !=None):       #if dest is an applicible var
                    new_dest = dest +"_%s"%global_counter
                    var_dict.update({dest:new_dest})
                    end_var_dict[dest] = new_dest
                    if(beg_var_dict.get(dest) ==None):
                        beg_var_dict[dest] = new_dest
                    dest = new_dest
                    new_var = new_var + [dest]
                    global_counter = global_counter +1
                inst = one_match[2]
                arg = one_match[3]
                if(re.match("_new_name|vr",arg)!=None):         #if arg is an applicible var
                    if(var_dict.get(arg)):                      #if arg has already been numbered
                        new_arg = var_dict.get(arg)
                    else:                                       #else make arg a numbered var
                        new_arg = arg +"_%s"%global_counter
                        global_counter = global_counter +1
                        new_var = new_var + [new_arg]
                    end_var_dict[arg] = new_arg
                    if(beg_var_dict.get(arg) ==None):
                        beg_var_dict[arg] = new_arg
                    arg = new_arg
                #replacing the instruction
                instr = dest + "=" + inst + "(" + arg + ");"
                b[index] = instr

            elif(assi):
                dest = assi[1]
                if(re.match("_new_name|vr",dest) !=None):           #if dest is an applicible var
                    new_dest = dest +"_%s"%global_counter
                    var_dict.update({dest:new_dest})
                    end_var_dict[dest] = new_dest
                    if(beg_var_dict.get(dest) ==None):
                        beg_var_dict[dest] = new_dest
                    dest = new_dest
                    new_var = new_var + [dest]
                    global_counter = global_counter +1
                arg = assi[2]
                arg = arg[:len(arg)-1]
                if(re.match("_new_name|vr",arg)!=None):             #if arg is an applicible var
                    if(var_dict.get(arg)):                          #if arg has already been numbered
                        new_arg = var_dict.get(arg)
                    else:                                           #else make arg a numbered var
                        new_arg = arg +"_%s"%global_counter
                        global_counter = global_counter +1
                        new_var = new_var + [new_arg]
                    end_var_dict[arg] = new_arg
                    if(beg_var_dict.get(arg) ==None):
                        beg_var_dict[arg] = new_arg
                    arg = new_arg
                #replacing the instruction
                instr = dest + "="  + arg + ";"
                b[index] = instr   
            #defunct patching code     
#        for x in beg_var_dict:
#            b.insert(new_name_counter, "%s=%s;"%(beg_var_dict.get(x),x))
#        for x in end_var_dict:
#            b.append("%s=%s;"%(x,end_var_dict.get(x)))
        
        #lvn optimazation code
        hashtable = {}
        for instr in b:
            index = b.index(instr)
            instr = instr.replace(" ","")
            two_match= re.match("(\S+)=(\S+)\((\S+),(\S+)\)",instr)
            if(two_match):
                lhs = two_match[1]
                rhs = two_match[3] + two_match[2] + two_match[4]
                look = hashtable.get(rhs)
                if(look != None):        #if in hashtable   
                    instr = lhs + "="  +look+";"        #replace instruction with found variable from hashtable
                    b[index] = instr
                    replaced_instr = replaced_instr +1
                else:                   #if not in hashtable, add it
                    hashtable[rhs] = lhs
    new_prog = []
    for b in block_list:
        new_prog = new_prog + b
    return new_prog,new_var,replaced_instr
