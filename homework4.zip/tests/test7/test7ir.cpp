
// LVN replaced 0 arithmetic instructions
#include "../../classir.h"
void test7(int &x,int &y){
virtual_reg vr0;
virtual_reg vr1;
virtual_reg vr2;
virtual_reg vr3;
virtual_reg vr4;
virtual_reg vr5;
virtual_reg vr6;
virtual_reg vr7;
virtual_reg vr8;
virtual_reg vr9;
virtual_reg vr10;
virtual_reg vr11;

virtual_reg vr0_0;
virtual_reg _new_name0_1;
virtual_reg vr1_2;
virtual_reg _new_name1_3;
virtual_reg vr2_4;
virtual_reg vr3_5;
virtual_reg vr4_6;
virtual_reg _new_name2_7;
virtual_reg vr11_8;
virtual_reg vr5_9;
virtual_reg vr6_10;
virtual_reg _new_name2_11;
virtual_reg vr9_12;
virtual_reg _new_name0_13;
virtual_reg _new_name1_14;
virtual_reg vr10_15;
virtual_reg _new_name0_16;
virtual_reg _new_name1_17;
virtual_reg vr7_18;
virtual_reg vr8_19;
virtual_reg _new_name2_20;
virtual_reg _new_name2_21;
virtual_reg _new_name0;
virtual_reg _new_name1;
virtual_reg _new_name2;
vr0_0=int2vr(1);
_new_name0_1=vr0_0;
vr1_2=int2vr(1);
_new_name1_3=vr1_2;
vr2_4=int2vr(0);
x=vr2int(vr2_4);
vr3_5=int2vr(0);
y=vr2int(vr3_5);
vr4_6=int2vr(0);
_new_name2_7=vr4_6;
vr11_8=int2vr(0);
label1:
vr5_9=int2vr(1024);
vr6_10=lti(_new_name2_11,vr5_9);
beq (vr6, vr11, label0);
vr9_12=addi(_new_name0_13,_new_name1_14);
x=vr2int(vr9_12);
vr10_15=addi(_new_name0_16,_new_name1_17);
y=vr2int(vr10_15);
vr7_18=int2vr(1);
vr8_19=addi(_new_name2_20,vr7_18);
_new_name2_21=vr8_19;
branch(label1);
label0:
return;
}
        
