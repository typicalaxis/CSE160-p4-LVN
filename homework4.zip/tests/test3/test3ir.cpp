
// LVN replaced 0 arithmetic instructions
#include "../../classir.h"
void test2(int &x,int &y){
virtual_reg vr0;
virtual_reg vr1;
virtual_reg vr2;
virtual_reg vr3;
virtual_reg vr4;
virtual_reg vr5;
virtual_reg vr6;

virtual_reg vr0_0;
virtual_reg vr6_1;
virtual_reg vr1_0;
virtual_reg vr2_1;
virtual_reg vr3_0;
virtual_reg vr4_1;
virtual_reg vr5_2;
vr0_0=int2vr(1);
vr6_1=int2vr(0);
beq (vr0, vr6, label1);
vr1_0=int2vr(1);
x=vr2int(vr1_0);
vr2_1=int2vr(1);
y=vr2int(vr2_1);
branch(label0);
label1:
vr3_0=int2vr(5);
x=vr2int(vr3_0);
vr4_1=float2vr(5.0);
vr5_2=vr_float2int(vr4_1);
y=vr2float(vr5_2);
label0:
return;
}
        
