
// LVN replaced 1 arithmetic instructions
#include "../../classir.h"
void test6(int &x,int &y){
virtual_reg vr0;
virtual_reg vr1;
virtual_reg vr2;
virtual_reg vr3;

virtual_reg vr0_0;
virtual_reg _new_name1_1;
virtual_reg vr1_2;
virtual_reg _new_name0_3;
virtual_reg vr2_4;
virtual_reg vr3_5;
virtual_reg _new_name0;
virtual_reg _new_name1;
vr0_0=int2vr(10);
_new_name1_1=vr0_0;
vr1_2=int2vr(10);
_new_name0_3=vr1_2;
vr2_4=addi(_new_name0_3,_new_name1_1);
x=vr2int(vr2_4);
vr3_5=vr2_4;
y=vr2int(vr3_5);
return;
}
        
