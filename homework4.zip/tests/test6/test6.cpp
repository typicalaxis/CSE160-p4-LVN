
void test6(int &x, int &y) {

  int i;
  int j;
  j = 10;
  i = 10;
  x = i + j;
  y = i + j;

}
