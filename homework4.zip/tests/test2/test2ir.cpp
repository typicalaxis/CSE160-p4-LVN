
// LVN replaced 0 arithmetic instructions
#include "../../classir.h"
void test2(float &f0,float &f1){
virtual_reg vr0;
virtual_reg vr1;
virtual_reg vr2;
virtual_reg vr3;
virtual_reg vr4;
virtual_reg vr5;

virtual_reg vr0_0;
virtual_reg vr1_1;
virtual_reg _new_name0_2;
virtual_reg vr2_3;
virtual_reg vr3_4;
virtual_reg _new_name1_5;
virtual_reg vr4_6;
virtual_reg _new_name0_7;
virtual_reg vr5_8;
virtual_reg _new_name0;
virtual_reg _new_name1;
vr0_0=float2vr(f0);
vr1_1=vr_float2int(vr0_0);
_new_name0_2=vr1_1;
vr2_3=float2vr(f1);
vr3_4=vr_float2int(vr2_3);
_new_name1_5=vr3_4;
vr4_6=addi(_new_name0_2,_new_name1_5);
_new_name0_7=vr4_6;
vr5_8=vr_int2float(_new_name0_7);
f0=vr2int(vr5_8);
return;
}
        
