
// LVN replaced 0 arithmetic instructions
#include "../../classir.h"
void test4(float &x){
virtual_reg vr0;
virtual_reg vr1;
virtual_reg vr2;
virtual_reg vr3;
virtual_reg vr4;
virtual_reg vr5;
virtual_reg vr6;
virtual_reg vr7;
virtual_reg vr8;

virtual_reg vr0_0;
virtual_reg _new_name0_1;
virtual_reg vr8_2;
virtual_reg vr1_0;
virtual_reg vr2_1;
virtual_reg _new_name0_2;
virtual_reg vr5_0;
virtual_reg vr7_1;
virtual_reg _new_name0_2;
virtual_reg vr6_3;
virtual_reg vr3_4;
virtual_reg vr4_5;
virtual_reg _new_name0_6;
virtual_reg _new_name0_7;
virtual_reg _new_name0;
vr0_0=int2vr(0);
_new_name0_1=vr0_0;
vr8_2=int2vr(0);
label1:
vr1_0=int2vr(1024);
vr2_1=lti(_new_name0_2,vr1_0);
beq (vr2, vr8, label0);
vr5_0=float2vr(x);
vr7_1=vr_int2float(_new_name0_2);
vr6_3=addf(vr5_0,vr7_1);
x=vr2float(vr6_3);
vr3_4=int2vr(1);
vr4_5=addi(_new_name0_6,vr3_4);
_new_name0_7=vr4_5;
branch(label1);
label0:
return;
}
        
